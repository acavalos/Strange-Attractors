import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class chaos_final extends PApplet {

int n = 5000;
float hue,sat,bri,alph;
int pause = 0;
int MODE = 0;

// Zoom and translation levels
float scale,zoom;
float dx,dy;
int log;

float[] coeff = new float[12];
dustparticle[] dust = new dustparticle[n];

public void setup() {
  
  colorMode(HSB,100,100,100,100);
  
  hue = random(0,100);
  sat = random(0,100);
  bri = random(0,100);
  alph = 1;
  background(hue,sat,bri);
  
  scale = width/2;
  dx = 0;
  dy = 0;
  
  for(int i=0;i<12;i++) {
    coeff[i] = random(-1,1); 
  }
  
  for(int i=0;i<dust.length;i++) {
    dust[i] = new dustparticle(); 
  }
}

public void draw() {
  int log = floor(log(width)/log(10));
  float zoom = pow(10,log-1);
  
  if(MODE==1) {
    background(hue,sat,bri);
    alph = 100;
  } else {
    alph = 1;
  }
  
// Controls for changing the plot
  if(keyPressed == true) {
    clear(); 
    background(hue,sat,bri);
    
    if (key == 'w') {
      dy -= zoom; 
    }
    
    if(key == 's') {
      dy += zoom; 
    }
   
    if(key == 'a') {
      dx -= zoom; 
    }
    if(key == 'd') {
      dx += zoom; 
    }


    if(key == 'r') {
      hue = random(0,100);
       sat = random(0,100);
       bri = random(0,100);  
       background(hue,sat,bri);
     }
  }
  
  translate(width/2 + dx,height/2 + dy);
  
  for(int i=0;i<dust.length;i++) {
    dust[i].update();
    dust[i].show();
  }
}

public float sign(float x){
  if(x!=0) {
    return x/abs(x); 
  } else {
    return 0;
  }
}
//Adjust mode
public void keyPressed() {
  if(key == 'm') {
    MODE = 1 - MODE; 
  }
  if(key == 'n') {
    setup(); 
  }
}

public void mouseWheel(MouseEvent event) {
    float e = event.getCount();
    println(e,sign(e));
    scale *= pow(1-sign(e)*0.05f,abs(e));
    background(hue,sat,bri);
  }
class dustparticle {
  PVector pos;
  int life;
  float max_life;
  
  dustparticle() {
    pos = newPVec();
    life = 0;
    max_life = random(1,9);
  }
  
  public void update() {
    PVector pold = pos;
    pos.x = coeff[0] + coeff[1]*pold.x + coeff[2]*pold.y + coeff[6]*pold.x*pold.y + coeff[8]*pold.x*pold.x + coeff[9]*pold.y*pold.y; 
    pos.y = coeff[3] + coeff[4]*pold.x + coeff[5]*pold.y + coeff[7]*pold.x*pold.y + coeff[10]*pold.x*pold.x + coeff[11]*pold.y*pold.y;
    
    if( pos.mag() > 2*scale || life >= max_life) {
      pos = newPVec();
      max_life = random(5,50);
      life = 0;
    } else {
      life += 1; 
    }
  }
  
  public void show() {
    noStroke();
    fill(100 - hue,100 - sat,100 - bri, 1);
    if(life!=0) {
      ellipse(scale * pos.x,scale * pos.y,2,alph);
    }
  }
}

public PVector newPVec() {
  PVector out = new PVector(random(-1,1), random(-1,1));
  return out;
}
  public void settings() {  size(640,480,P2D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "chaos_final" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
